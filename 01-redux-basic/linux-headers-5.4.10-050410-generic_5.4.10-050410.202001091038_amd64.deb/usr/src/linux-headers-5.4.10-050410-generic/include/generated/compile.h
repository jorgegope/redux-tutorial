/* This file is auto generated, version 202001091038 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#202001091038 SMP Thu Jan 9 10:41:11 UTC 2020"
#define LINUX_COMPILE_BY "kernel"
#define LINUX_COMPILE_HOST "kathleen"
#define LINUX_COMPILER "gcc version 9.2.1 20191130 (Ubuntu 9.2.1-21ubuntu1)"
